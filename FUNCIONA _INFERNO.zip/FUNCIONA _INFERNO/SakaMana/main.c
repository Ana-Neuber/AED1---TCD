#include "restaurante.h"
#include "cliente.h"
#include "prato.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>

// retorno -2 -> lista nao criada
// retorno -1 -> lista vazia
// retorno  0 -> opera��o realizada
// retorno -3 - > valores invalidos

//fun��o que salva lista no arquivo
//fun��o que carrega lista com o arquivo

int confereCPF(char* cpf);
int confereEmail(char *email);
int confereSenha(char *senha);
int confereCNPJ(char *cnpj);

int main ()
{
    setlocale(LC_ALL, "Portuguese");

    int menu_inicial, menu_cliente_inicio, menu_cliente, menu_restaurante_inicio, menu_restaurante;
    int retorno, opcao;
    char aux[15];
    Cliente auxC, alterarC;
    Restaurante auxR;
    Prato auxP;

    ListaC *lc;
    ListaR *lr;

    lc = criarC();
    lr = criarR();

    do //menu
    {
        printf("---MENU---\n");
        printf("1.Cliente.\n");
        printf("2.Restaurante.\n");
        printf("0.Sair.\n");

        printf("Digite sua opcao:");
        scanf("%d",&menu_inicial);

        system("cls");
        switch(menu_inicial)
        {
            case 0:
                // salvar arquivos aqui
                printf("Saindo...\n");
                break;

            case 1:
                do
                {
                    printf("---MENU CLIENTE---\n");
                    printf("1.Login.\n");
                    printf("2.Cadastro.\n");
                    printf("0.Sair.\n");

                    printf("Digite sua opcao:\n");
                    scanf("%d",&menu_cliente_inicio);

                    system("cls");
                    switch(menu_cliente_inicio)
                    {
                        case 0:
                            break;

                        case 1: // a fazer (login ja feito)
                            //entrada de dados de login
                            do{
                                printf("E-mail: ");
                                fflush(stdin);
                                fgets(auxC.email,50,stdin);
                                auxC.email[strcspn(auxC.email,"\n")]='\0';
                                retorno = confereEmail(auxC.email);
                                if(retorno){
                                    printf("E-mail inv�lido! Digite novamente.\n\n");
                                }
                                else if(procuraEmailCliente(lc,auxC.email)!=0){
                                    retorno = 1;
                                    printf("E-mail n�o cadastrado! Digite novamente.\n\n");
                                }
                            }while(retorno);
                            buscaItemCliente(lc,auxC.email,&auxC);
                            do{
                                printf("Senha: ");
                                fflush(stdin);
                                fgets(aux,15,stdin);
                                aux[strcspn(aux,"\n")]='\0';
                                retorno = confereSenha(aux);
                                if(retorno){
                                    printf("A senha deve conter pelo menos um caratere mai�sculo, um n�mero e um caractere especial! Digite novamente.\n\n");
                                }
                                else if(strcmp(aux, auxC.senha)!=0){
                                    printf("Senha incorreta! Digite novamente!");
                                    retorno = 1;
                                }
                            }while(retorno);

                            //login aceito
                            system("cls");
                            do
                            {
                                printf("Bem vindo %s\n", auxC.nome);
                                printf("1.Ver restaurantes.\n");
                                printf("2.Ver pratos.\n");
                                printf("3.Ver carrinho.\n");
                                printf("4.Alterar cadastro.\n");
                                printf("5.Excluir conta.\n");
                                printf("0.Sair.\n");

                                printf("Digite sua opcao:\n");
                                scanf("%d",&menu_cliente);

                                system("cls");
                                switch(menu_cliente)
                                {
                                    case 0: break;

                                    case 1:
                                        //Fun��o ver restaurantes(mostrar).

                                        break;

                                    case 2:
                                        //Fun��o ver pratos(mostrar).

                                        break;

                                    case 3:
                                        //Fun��o para ver carrinho.

                                        break;

                                    case 4:
                                        // feito
                                        printf("======= DADOS DE CADASTRO =======\n\n");

                                        do{
                                            printf("Nome atual: %s\n", auxC.nome);
                                            printf("Deseja alterar seu nome de usu�rio?\n\n");
                                            printf("1. Sim\n");
                                            printf("0. N�o\n");
                                            printf("Op��o escolhida: ");
                                            scanf("%d",&opcao);

                                            system("cls");
                                            switch(opcao){
                                            case 1:
                                                printf("\nDigite seu novo nome de usu�rio: ");
                                                fflush(stdin);
                                                fgets(auxC.nome,30,stdin);
                                                auxC.nome[strcspn(auxC.nome,"\n")]='\0';
                                                break;
                                            case 0:
                                                break;
                                            default:
                                                system("cls");
                                                printf("Op��o inv�lida, tente novamente!\n");
                                            }
                                        }while((opcao!=1)&&(opcao!=0));

                                        do{
                                            printf("E-mail atual: %s\n", auxC.email);
                                            printf("Deseja alterar seu e-mail?\n\n");
                                            printf("1. Sim\n");
                                            printf("0. N�o\n");
                                            printf("Op��o escolhida: ");
                                            scanf("%d",&opcao);

                                            system("cls");
                                            switch(opcao){
                                            case 1:
                                                printf("\nDigite seu novo e-mail: ");
                                                fflush(stdin);
                                                fgets(auxC.email,50,stdin);
                                                auxC.email[strcspn(auxC.email,"\n")]='\0';
                                                retorno = confereEmail(auxC.email);
                                                if(retorno){
                                                    system("cls");
                                                    printf("E-mail inv�lido, digite novamente!\n");
                                                    opcao = -1;
                                                }
                                                else if(procuraEmailCliente(lc,auxC.email)==0){
                                                    system("cls");
                                                    printf("E-mail j� cadastrado! Tente novamente.\n");
                                                }
                                                break;
                                            case 0:
                                                break;
                                            default:
                                                system("cls");
                                                printf("Op��o inv�lida, tente novamente!\n");
                                            }
                                        }while((opcao!=1)&&(opcao!=0));

                                        do{
                                            printf("Deseja alterar sua senha?\n\n");
                                            printf("1. Sim\n");
                                            printf("0. N�o\n");
                                            printf("Op��o escolhida: ");
                                            scanf("%d",&opcao);

                                            system("cls");
                                            switch(opcao){
                                            case 1:
                                                printf("Digite sua senha atual: ");
                                                fflush(stdin);
                                                fgets(aux,15,stdin);
                                                aux[strcspn(aux,"\n")]='\0';
                                                if(strcmp(aux,auxC.senha)!=0){
                                                    system("cls");
                                                    printf("Senha incorreta!\n");
                                                    break;
                                                }
                                                printf("\nDigite sua nova senha (min. 8 caracteres): ");
                                                fflush(stdin);
                                                fgets(auxC.senha,15,stdin);
                                                auxC.senha[strcspn(auxC.senha,"\n")]='\0';
                                                retorno = confereSenha(auxC.senha);
                                                if(retorno){
                                                    system("cls");
                                                    printf("A senha deve conter pelo menos um caratere mai�sculo, um n�mero e um caractere especial! Digite novamente.\n\n");
                                                    opcao = -1;
                                                }
                                                break;
                                            case 0:
                                                break;
                                            default:
                                                system("cls");
                                                printf("Op��o inv�lida, tente novamente!");
                                            }
                                        }while((opcao!=1)&&(opcao!=0));

                                        retorno = 1;
                                        if(removerCliente(lc,auxC)==0){
                                                retorno = inserirCliente(lc,auxC);
                                        }

                                        if(retorno){
                                            printf("Erro ao alterar!\n");
                                        }
                                        else{
                                            printf("Dados alterados com sucesso!\n");
                                        }
                                        break;

                                    case 5:
                                        //Fun��o de excluir a conta (dar um free nessa bomba).

                                        break;

                                    default:
                                        printf("Opcao invalida... Tente novamente.\n");
                                }
                            } while(menu_cliente);

                            break;

                        case 2://feito

                            printf("======= DADOS DE CADASTRO =======\n\n");
                            printf("Nome: ");
                            fflush(stdin);
                            fgets(auxC.nome,29,stdin);
                            auxC.nome[strcspn(auxC.nome,"\n")]='\0';
                            do{
                                printf("CPF (111.111.111-11): ");
                                fflush(stdin);
                                fgets(auxC.cpf,15,stdin);
                                retorno = confereCPF(auxC.cpf);
                                if(retorno){
                                    printf("CPF inv�lido! Digite novamente.\n\n");
                                }
                                else if(procuraItemCliente(lc,auxC.cpf)==0){
                                    retorno = 1;
                                    printf("CPF j� cadastrado! Digite novamente.\n\n");
                                }
                            }while(retorno);

                            do{
                                printf("E-mail: ");
                                fflush(stdin);
                                fgets(auxC.email,50,stdin);
                                retorno = confereEmail(auxC.email);
                                auxC.email[strcspn(auxC.email,"\n")]='\0';
                                if(retorno){
                                    printf("E-mail inv�lido! Digite novamente.\n\n");
                                }
                                else if(procuraEmailCliente(lc,auxC.email)==0){
                                    retorno = 1;
                                    printf("E-mail j� cadastrado! Digite novamente.\n\n");
                                }
                            }while(retorno);

                            do{
                                printf("Senha (min. 8 caracteres): ");
                                fflush(stdin);
                                fgets(auxC.senha,15,stdin);
                                auxC.senha[strcspn(auxC.senha,"\n")]='\0';
                                retorno = confereSenha(auxC.senha);
                                if(retorno){
                                    printf("A senha deve conter pelo menos um caratere mai�sculo, um n�mero e um caractere especial! Digite novamente.\n\n");
                                }
                            }while(retorno);

                            retorno = inserirCliente(lc, auxC);

                            system("cls");
                            if(retorno==0){
                                printf("Cliente cadastrado com sucesso!\n\n");
                            }
                            else{
                                printf("Erro ao cadastrar!\n\n");
                            }
                        break;

                        default:
                            printf("Opcao invalida... Tente novamente.\n");
                    }
                } while(menu_cliente_inicio);

                break;

            case 2:
                do
                {
                    printf("---MENU RESTAURANTE---\n");
                    printf("1.Login.\n");
                    printf("2.Cadastro.\n");
                    printf("0.Sair.\n");

                    printf("Digite sua opcao:\n");
                    scanf("%d",&menu_restaurante_inicio);

                    system("cls");
                    switch(menu_restaurante_inicio)
                    {
                        case 0: break;

                        case 1: //falta fazer (login feito)
                            //entrada de dados de login
                            do{
                                printf("E-mail: ");
                                fflush(stdin);
                                fgets(auxR.email,50,stdin);
                                auxR.email[strcspn(auxR.email,"\n")]='\0';
                                retorno = confereEmail(auxR.email);
                                if(retorno){
                                    printf("E-mail inv�lido! Digite novamente.\n\n");
                                }
                                else if(procuraEmailRestaurante(lr,auxR.email)!=0){
                                    retorno = 1;
                                    printf("E-mail n�o cadastrado! Digite novamente.\n\n");
                                }
                            }while(retorno);
                            buscaItemRestaurante(lr,auxR.email,&auxR);
                            do{
                                printf("Senha: ");
                                fflush(stdin);
                                fgets(aux,15,stdin);
                                aux[strcspn(aux,"\n")]='\0';
                                retorno = confereSenha(aux);
                                if(retorno){
                                    printf("A senha deve conter pelo menos um caratere mai�sculo, um n�mero e um caractere especial! Digite novamente.\n\n");
                                }
                                else if(strcmp(aux, auxR.senha)!=0){
                                    printf("Senha incorreta! Digite novamente!");
                                    retorno = 1;
                                }
                            }while(retorno);

                            system("cls");
                            do
                            {
                                printf("Bem vindo, %s\n", auxR.nome_restaurante);
                                printf("1.Ver pratos.\n");
                                printf("2.Ver pedidos.\n"); //Opcional.
                                printf("3.Cadastrar prato.\n");
                                printf("4.Alterar prato.\n");
                                printf("5.Excluir prato.\n");
                                printf("6.Alterar dados do restaurante.\n");
                                printf("7.Excluir conta.\n");
                                printf("0.Sair.\n");

                                printf("Digite sua opcao:\n");
                                scanf("%d",&menu_restaurante);

                                system("cls");
                                switch(menu_restaurante)
                                {
                                    case 0: break;

                                    case 1:
                                        //Fun��o ver pratos(mostrar).

                                        break;

                                    case 2:
                                        //Fun��o ver pedidos(mostrar).

                                        break;

                                    case 3:
                                        //Fun��o para cadastrar prato.

                                        break;

                                    case 4:
                                        //Fun��o de alterar o prato.

                                        break;

                                    case 5:
                                        //Fun��o de excluir o prato (dar um free nessa bomba).

                                        break;

                                    case 6:
                                        //Alterar dados.

                                        break;

                                    case 7:
                                        //Excluir conta FREE NESSA BOMBA).

                                        break;

                                    default:
                                        printf("Opcao invalida...Tente novamente.\n");
                                }
                            } while(menu_restaurante);

                            break;

                        case 2://feito

                            printf("======= DADOS DE CADASTRO =======\n\n");
                            printf("Nome: ");
                            fflush(stdin);
                            fgets(auxR.nome_proprietario,29,stdin);
                            auxR.nome_proprietario[strcspn(auxR.nome_proprietario,"\n")]='\0';
                            printf("Nome do Restaurante: ");
                            fflush(stdin);
                            fgets(auxR.nome_restaurante,29,stdin);
                            auxR.nome_restaurante[strcspn(auxR.nome_restaurante,"\n")]='\0';
                            do{
                                printf("CNPJ (XX.XXX.XXX/0001-XX): ");
                                fflush(stdin);
                                fgets(auxR.cnpj,18,stdin);
                                retorno = confereCNPJ(auxR.cnpj);
                                if(retorno){
                                    printf("CNPJ inv�lido! Digite novamente.\n\n");
                                }
                                else if(procuraItemRestaurante(lr,auxR.cnpj)==0){
                                    retorno = 1;
                                    printf("CNPJ j� cadastrado! Digite novamente.\n\n");
                                }
                            }while(retorno);

                            do{
                                printf("E-mail: ");
                                fflush(stdin);
                                fgets(auxR.email,50,stdin);
                                retorno = confereEmail(auxR.email);
                                auxR.email[strcspn(auxR.email,"\n")]='\0';
                                if(retorno){
                                    printf("E-mail inv�lido! Digite novamente.\n\n");
                                }
                                else if(procuraEmailRestaurante(lr,auxR.email)==0){
                                    retorno = 1;
                                    printf("E-mail j� cadastrado! Digite novamente.\n\n");
                                }
                            }while(retorno);

                            do{
                                printf("Senha (min. 8 caracteres): ");
                                fflush(stdin);
                                fgets(auxR.senha,15,stdin);
                                auxR.senha[strcspn(auxR.senha,"\n")]='\0';
                                retorno = confereSenha(auxR.senha);
                                if(retorno){
                                    printf("A senha deve conter pelo menos um caratere mai�sculo, um n�mero e um caractere especial! Digite novamente.\n\n");
                                }
                            }while(retorno);

                            retorno = inserirRestaurante(lr, auxR);

                            system("cls");
                            if(retorno==0){
                                printf("Restaurante cadastrado com sucesso!\n\n");
                            }
                            else{
                                printf("Erro ao cadastrar!\n\n");
                            }
                            break;

                        default:
                            printf("Opcao invalida... Tente novamente.\n");
                    }
                } while(menu_restaurante_inicio);

                break;

                    default:
                        printf("Opcao invalida... Tente novamente.\n");
        }
    } while(menu_inicial);

    return 0;
}

int confereCPF(char *cpf){
    int i, tam=0;
    for(i=0; cpf[i]!='\0'; i++){
        if((i!=3 && i!=7 && i!=11) && (cpf[i]<'0' && cpf[i]>'9')) return -1;
        tam++;
    }
    if(cpf[11]!='-') return -1;
    if(cpf[3]!='.' || cpf[7]!='.') return -1;
    if(tam<14) return -1;
    return 0;
}

int confereEmail(char *email){
    int i, arroba=0, ponto = 0;
    for(i=0; email[i]!='\0'; i++){
        if(email[i]=='@') arroba++;
        else if(email[i]=='.' && arroba==1) ponto++;
    }
    if(arroba!=1) return -1;
    if(ponto!=1) return -1;

    return 0;
}

int confereSenha(char *senha){
    int i, maiuscula=0, numero = 0, especial = 0, tam=0;
    for(i=0; senha[i]!='\0'; i++){
        if(senha[i]>='A' && senha[i]<='Z') maiuscula++;
        else if(senha[i]>='1' && senha[i]<='9') numero++;
        else if((senha[i]>='!' && senha[i]<='@')||(senha[i]>=':' && senha[i]<='?')) especial++;
        tam++;
    }
    if(maiuscula && especial && numero &&(tam>=8)) return 0;
    return -1;
}

int confereCNPJ(char *cnpj){
    int i, tam=0;
    for(i=0; cnpj[i]!='\0'; i++){
        if((i!=2 && i!=6 && i<10 && i>15) && (cnpj[i]<'0' && cnpj[i]>'9')) return -1;
        tam++;
    }

    if(tam!=17) return -1;
    if(cnpj[15]!='-') return -1;
    if(cnpj[2]!='.' || cnpj[6]!='.') return -1;
    if(cnpj[10]!='/') return -1;
    if(cnpj[11]!='0' || cnpj[12]!='0' || cnpj[13]!='0' || (cnpj[14]!='1' && cnpj[14]!='2')) return -1;


    return 0;
}

int escondeSenha(char *senha){
    char senha1[15];

    strcpy(senha,senha1);
}
