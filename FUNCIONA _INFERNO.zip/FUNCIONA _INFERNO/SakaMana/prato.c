#include "restaurante.h"
#include "prato.h"
#include "cliente.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct no_p{
    Prato dados;
    struct no_p* prox;
}noP;

typedef struct lista_p{
    noP* inicio;
}ListaP;

ListaP *criarP(){
    ListaP *lp = (ListaP *)malloc(sizeof(ListaP));
    lp->inicio=NULL;
    return lp;
}

int inserirPrato(ListaP *lp, Prato it){
    if(lp == NULL)return -2;
    noP *noLista = (noP*)malloc(sizeof(noP));
    noLista->dados = it;

    noLista->prox = lp->inicio;
    lp->inicio = noLista;
    return 0;
}

int removerPrato(ListaP *lp, Prato it){
    if(lp == NULL) return -2;
    if(listaVaziaP(lp)==0)return -1;
    noP *no = lp->inicio;
    noP *aux = NULL;
    while(no != NULL){
        if(strcmp(no->dados.codigo, it.codigo)!=0){
            aux = no;
            no = no->prox;
        }
        else break;
    }
    if(no==NULL) return -3;
    if(aux!=NULL) aux->prox = no->prox;
    else lp->inicio = no->prox;
    free(no);
    return 0;
}

int listaVaziaP(ListaP *lp){
    if(lp == NULL) return -2;
    if(lp->inicio == NULL) return 0;
    else return -1;
}

int alterarPrato(ListaP *lp, Prato it){
    if(lp==NULL)return -2;
    if(listaVaziaP(lp)==0) return -1;
    noP *no = lp->inicio;
    while(no != NULL){
        if(strcmp(no->dados.codigo, it.codigo)!=0){
            no = no->prox;
        }
        else break;
    }
    if(no==NULL) return -3;
    if(it.nome[0] != '0') strcpy(no->dados.nome,it.nome);
    if(it.ingredientes[0] != '0') strcpy(no->dados.ingredientes,it.ingredientes);
    if(it.preco != 0) no->dados.preco = it.preco;
    return 0;
}

int buscaItemPrato(ListaP *lp,char *cod, Prato *it){
    if(lp==NULL)return -2;
    if(listaVaziaP(lp)==0) return -1;
    noP *no = lp->inicio;
    while(no != NULL){
        if(strcmp(no->dados.codigo, cod)!=0){
            no = no->prox;
        }
        else break;
    }
    if(no==NULL) return -3;
    *it = no->dados;
    return 0;
}

int procuraItemPrato(ListaP *lp,char *cod){
    if(lp==NULL)return -2;
    if(listaVaziaP(lp)==0) return -1;
    noP *no = lp->inicio;
    while(no != NULL){
        if(strcmp(no->dados.codigo, cod)!=0){
            no = no->prox;
        }
        else return 0;
    }
    return -3;
}
