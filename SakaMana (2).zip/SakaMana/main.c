#include "restaurante.h"
#include "cliente.h"
#include "prato.h"
#include "pedidos.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>

// retorno -2 -> lista nao criada
// retorno -1 -> lista vazia
// retorno  0 -> opera��o realizada
// retorno -3 - > valores invalidos

//fun��o que salva lista no arquivo
//fun��o que carrega lista com o arquivo

int confereCPF(char* cpf);
int confereEmail(char *email);
int confereSenha(char *senha);
int confereCNPJ(char *cnpj);


void mostraCategoria(char *categoria);
void escondeSenha(char *senha);

int main ()
{
    setlocale(LC_ALL, "Portuguese");

    int menu_inicial, menu_cliente_inicio, menu_cliente, menu_restaurante_inicio, menu_restaurante;
    int retorno, opcao, codigo;
    char aux[15], categoria[30];
    Cliente auxC;
    Restaurante auxR;
    Prato auxP;

    ListaC *lc;
    ListaR *lr;

    lc = criarC();
    lr = criarR();

    do //menu
    {
        printf("---MENU---\n");
        printf("1.Cliente.\n");
        printf("2.Restaurante.\n");
        printf("0.Sair.\n");

        printf("Digite sua opcao:");
        scanf("%d",&menu_inicial);

        system("cls");
        switch(menu_inicial)
        {
            case 0:
                // salvar arquivos aqui
                printf("Saindo...\n");
                break;

            case 1:
                do
                {
                    printf("---MENU CLIENTE---\n");
                    printf("1.Login.\n");//feito
                    printf("2.Cadastro.\n");//feito
                    printf("0.Sair.\n");//feito

                    printf("Digite sua opcao:\n");
                    scanf("%d",&menu_cliente_inicio);

                    system("cls");
                    switch(menu_cliente_inicio)
                    {
                        case 0:
                            break;

                        case 1:
                            do{
                                printf("E-mail: ");
                                fflush(stdin);
                                fgets(auxC.email,50,stdin);
                                auxC.email[strcspn(auxC.email,"\n")]='\0';
                                retorno = confereEmail(auxC.email);
                                if(retorno){
                                    printf("E-mail inv�lido! Digite novamente.\n\n");
                                }
                                else if(procuraEmailCliente(lc,auxC.email)!=0){
                                    retorno = 1;
                                    printf("E-mail n�o cadastrado! Digite novamente.\n\n");
                                }
                            }while(retorno);
                            buscaItemCliente(lc,auxC.email,&auxC);
                            do{
                                printf("Senha: ");
                                escondeSenha(aux);
                                aux[strcspn(aux,"\n")]='\0';
                                retorno = confereSenha(aux);
                                if(retorno){
                                    printf("A senha deve conter pelo menos um caratere mai�sculo, um n�mero e um caractere especial! Digite novamente.\n\n");
                                }
                                else if(strcmp(aux, auxC.senha)!=0){
                                    printf("\nSenha incorreta! Digite novamente!\n");
                                    retorno = 1;
                                }
                            }while(retorno);

                            //login aceito

                            do
                            {
                                system("cls");
                                printf("Bem vindo %s\n", auxC.nome);
                                printf("1.Ver restaurantes.\n");//feito
                                printf("2.Ver pratos.\n");//feito
                                printf("3.Ver meus pedidos.\n");//feito
                                printf("4.Alterar cadastro.\n");//feito
                                printf("5.Excluir conta.\n");//feito
                                printf("0.Sair.\n");//feito

                                printf("Digite sua opcao:\n");
                                scanf("%d",&menu_cliente);

                                system("cls");
                                switch(menu_cliente)
                                {
                                    case 0: break;

                                    case 1:

                                        do{
                                            mostraCategoria(categoria);
                                            system("cls");
                                            printf("=====RESTAURANTES=====\n\n");
                                            mostrarRestaurante(lr, categoria);
                                            printf("\n\nDeseja ver algum dos card�pios? \n");
                                            printf("1 - Sim\n");
                                            printf("0 - N�o\n");
                                            printf("op��o: ");
                                            scanf("%d", &opcao);
                                            switch(opcao){
                                                case 0: break;
                                                case 1:
                                                    printf("nEscolha o n�mero do card�pio: ");
                                                    scanf("%d", &opcao);
                                                    retorno = buscaCodigoRestaurante(lr, opcao, &auxR);
                                                    system("cls");
                                                    if(retorno){
                                                        printf("ERRO: op��o inv�lida!, digite novamente.\n");
                                                        opcao = 1;
                                                        break;
                                                    }
                                                    else{
                                                        do{
                                                            printf("====== CARD�PIO ======\n");
                                                            mostrarPratos(auxR.cardapio);
                                                            printf("\n\nDeseja adicionar algum dos pratos aos pedidos? \n");
                                                            printf("1 - Sim\n");
                                                            printf("0 - N�o\n");
                                                            printf("op��o: ");
                                                            scanf("%d", &opcao);
                                                            switch(opcao){
                                                                case 0: break;
                                                                case 1:
                                                                    printf("\nEscolha o n�mero do prato: ");
                                                                    scanf("%d", &opcao);
                                                                    retorno = buscaItemPrato(auxR.cardapio, opcao, &auxP);
                                                                    system("cls");
                                                                    if(retorno){
                                                                        printf("ERRO: op��o inv�lida!, digite novamente.\n");
                                                                        opcao = 1;
                                                                        break;
                                                                    }
                                                                    else{
                                                                        retorno = inserirPedido(auxR.pedidos, auxC, auxP);
                                                                        if(!retorno)printf("Pedido realizado!.\n");
                                                                        else printf("ERRO: N�o foi poss�vel fazer o pedido.\n");
                                                                    }
                                                            }
                                                            printf("\n\nDeseja ver os pratos novamente?\n");
                                                            printf("1 - Sim\n");
                                                            printf("0 - N�o\n");
                                                            printf("op��o: ");
                                                            scanf("%d", &opcao);
                                                            system("cls");
                                                        }while(opcao);
                                                    }
                                            }
                                            printf("\n\nDeseja ver os restaurantes novamente?\n");
                                            printf("1 - Sim\n");
                                            printf("0 - N�o\n");
                                            printf("op��o: ");
                                            scanf("%d", &opcao);
                                            system("cls");
                                        }while(opcao);

                                    break;

                                    case 2:


                                        do{
                                            printf("====== PRATOS ======\n");
                                            mostrarTodosPratos(lr);
                                            printf("\n\nDeseja adicionar algum dos pratos aos pedidos? \n");
                                            printf("1 - Sim\n");
                                            printf("0 - N�o\n");
                                            printf("op��o: ");
                                            scanf("%d", &opcao);
                                            switch(opcao){
                                                case 0: break;
                                                case 1:
                                                    printf("\nEscolha o n�mero do prato: ");
                                                    fflush(stdin);
                                                    scanf("%d", &opcao);
                                                    retorno = buscaCodigoRestaurante(lr, auxR.codigo, &auxR);
                                                    system("cls");
                                                    if(retorno){
                                                        printf("ERRO: op��o inv�lida!, digite novamente.\n");
                                                        opcao = 1;
                                                        break;
                                                    }
                                                    else{
                                                        retorno = buscaItemPrato(auxR.cardapio, opcao, &auxP);
                                                        if(retorno){
                                                            printf("ERRO: op��o inv�lida!, digite novamente.\n");
                                                            opcao = 1;
                                                            break;
                                                        }
                                                        else{
                                                           retorno = inserirPrato(auxC.carrinho, auxP);
                                                           if(retorno){
                                                                 printf("ERRO: N�o foi poss�vel fazer o pedido.\n");
                                                           }
                                                           else{
                                                                retorno = inserirPedido(auxR.pedidos, auxC, auxP);
                                                                if(!retorno)printf("Pedido realizado!.\n");
                                                                else printf("ERRO: N�o foi poss�vel fazer o pedido.\n");
                                                           }
                                                        }
                                                    }
                                            }
                                            printf("\nDeseja ver os pratos novamente?\n");
                                            printf("1 - Sim\n");
                                            printf("0 - N�o\n");
                                            printf("op��o: ");
                                            scanf("%d", &opcao);
                                            system("cls");
                                        }while(opcao);
                                        break;

                                    case 3:
                                        printf("====== PEDIDOS ======\n");
                                        mostrarPratos(auxC.carrinho);
                                        printf("Pressione qualquer tecla para voltar: ");
                                        fflush(stdin);
                                        getc(stdin);
                                        break;

                                    case 4:
                                        // feito
                                        printf("======= ALTERA��O DE CADASTRO =======\n\n");

                                        do{
                                            printf("Nome atual: %s\n", auxC.nome);
                                            printf("Deseja alterar seu nome de usu�rio?\n\n");
                                            printf("1. Sim\n");
                                            printf("0. N�o\n");
                                            printf("Op��o escolhida: ");
                                            scanf("%d",&opcao);

                                            system("cls");
                                            switch(opcao){
                                            case 1:
                                                printf("\nDigite seu novo nome de usu�rio: ");
                                                fflush(stdin);
                                                fgets(auxC.nome,30,stdin);
                                                auxC.nome[strcspn(auxC.nome,"\n")]='\0';
                                                break;
                                            case 0:
                                                break;
                                            default:
                                                system("cls");
                                                printf("Op��o inv�lida, tente novamente!\n");
                                            }

                                        }while((opcao!=1)&&(opcao!=0));

                                        do{
                                            printf("E-mail atual: %s\n", auxC.email);
                                            printf("Deseja alterar seu e-mail?\n\n");
                                            printf("1. Sim\n");
                                            printf("0. N�o\n");
                                            printf("Op��o escolhida: ");
                                            scanf("%d",&opcao);

                                            system("cls");
                                            switch(opcao){
                                            case 1:
                                                printf("\nDigite seu novo e-mail: ");
                                                fflush(stdin);
                                                fgets(auxC.email,50,stdin);
                                                auxC.email[strcspn(auxC.email,"\n")]='\0';
                                                retorno = confereEmail(auxC.email);
                                                if(retorno){
                                                    system("cls");
                                                    printf("E-mail inv�lido, digite novamente!\n");
                                                    opcao = -1;
                                                }
                                                else if(procuraEmailCliente(lc,auxC.email)==0){
                                                    system("cls");
                                                    printf("E-mail j� cadastrado! Tente novamente.\n");
                                                }
                                                break;
                                            case 0:
                                                break;
                                            default:
                                                system("cls");
                                                printf("Op��o inv�lida, tente novamente!\n");
                                            }
                                        }while((opcao!=1)&&(opcao!=0));

                                        do{
                                            printf("Deseja alterar sua senha?\n\n");
                                            printf("1. Sim\n");
                                            printf("0. N�o\n");
                                            printf("Op��o escolhida: ");
                                            scanf("%d",&opcao);

                                            system("cls");
                                            switch(opcao){
                                            case 1:
                                                printf("Digite sua senha atual: ");
                                                escondeSenha(aux);
                                                aux[strcspn(aux,"\n")]='\0';
                                                if(strcmp(aux,auxC.senha)!=0){
                                                    system("cls");
                                                    printf("Senha incorreta!\n");
                                                    break;
                                                }
                                                printf("\nDigite sua nova senha (min. 8 caracteres): ");
                                                escondeSenha(auxC.senha);
                                                auxC.senha[strcspn(auxC.senha,"\n")]='\0';
                                                retorno = confereSenha(auxC.senha);
                                                if(retorno){
                                                    system("cls");
                                                    printf("A senha deve conter pelo menos um caratere mai�sculo, um n�mero e um caractere especial! Digite novamente.\n\n");
                                                    opcao = -1;
                                                }
                                                break;
                                            case 0:
                                                break;
                                            default:
                                                system("cls");
                                                printf("Op��o inv�lida, tente novamente!");
                                            }
                                        }while((opcao!=1)&&(opcao!=0));

                                        retorno = 1;
                                        if(removerCliente(lc,auxC)==0){
                                                retorno = inserirCliente(lc,auxC);
                                        }

                                        if(retorno){
                                            system("cls");
                                            printf("Erro ao alterar!\n");
                                        }
                                        else{
                                            system("cls");
                                            printf("Dados alterados com sucesso!\n");
                                        }

                                        break;

                                    case 5:
                                        printf("Deseja mesmo excluir a sua conta permanentemente?\n");
                                        printf("1 - Sim\n");
                                        printf("0 - N�o\n");

                                        printf("Digite a sua op��o: ");
                                        scanf("%d", &opcao);

                                        while(opcao){
                                            printf("Digite sua senha para confirmar: ");
                                            escondeSenha(aux);
                                            aux[strcspn(aux,"\n")]='\0';
                                            if(strcmp(aux,auxC.senha)==0){
                                                retorno = removerCliente(lc, auxC);
                                                if(retorno){
                                                    system("cls");
                                                    printf("ERRO: n�o foi poss�vel remover o cliente!\n");
                                                }
                                                else{
                                                    opcao = 0;
                                                    menu_cliente = 0;
                                                    system("cls");
                                                    printf("Conta excluida com sucesso!\n");
                                                }
                                            }
                                            else{
                                                system("cls");
                                                printf("Senha inv�lida! Tente novamente. \n");
                                            }
                                        }

                                        break;

                                    default:
                                        printf("Opcao invalida... Tente novamente.\n");
                                }
                            } while(menu_cliente);

                            break;

                        case 2://feito

                            printf("======= DADOS DE CADASTRO =======\n\n");
                            printf("Nome: ");
                            fflush(stdin);
                            fgets(auxC.nome,29,stdin);
                            auxC.nome[strcspn(auxC.nome,"\n")]='\0';
                            do{
                                printf("CPF (111.111.111-11): ");
                                fflush(stdin);
                                fgets(auxC.cpf,15,stdin);
                                retorno = confereCPF(auxC.cpf);
                                if(retorno){
                                    printf("CPF inv�lido! Digite novamente.\n\n");
                                }
                                else if(procuraItemCliente(lc,auxC.cpf)==0){
                                    retorno = 1;
                                    printf("CPF j� cadastrado! Digite novamente.\n\n");
                                }
                            }while(retorno);

                            do{
                                printf("E-mail: ");
                                fflush(stdin);
                                fgets(auxC.email,50,stdin);
                                retorno = confereEmail(auxC.email);
                                auxC.email[strcspn(auxC.email,"\n")]='\0';
                                if(retorno){
                                    printf("E-mail inv�lido! Digite novamente.\n\n");
                                }
                                else if(procuraEmailCliente(lc,auxC.email)==0){
                                    retorno = 1;
                                    printf("E-mail j� cadastrado! Digite novamente.\n\n");
                                }
                            }while(retorno);

                            do{
                                printf("Senha (min. 8 caracteres): ");
                                escondeSenha(auxC.senha);
                                auxC.senha[strcspn(auxC.senha,"\n")]='\0';
                                retorno = confereSenha(auxC.senha);
                                if(retorno){
                                    printf("\nA senha deve conter pelo menos um caratere mai�sculo, um n�mero e um caractere especial! Digite novamente.\n\n");
                                }
                            }while(retorno);

                            retorno = inserirCliente(lc, auxC);

                            system("cls");
                            if(retorno==0){
                                printf("\nCliente cadastrado com sucesso!\n\n");
                            }
                            else{
                                printf("\nErro ao cadastrar!\n\n");
                            }
                        break;

                        default:
                            printf("\nOpcao invalida... Tente novamente.\n");
                    }
                } while(menu_cliente_inicio);

                break;

            case 2:
                do
                {
                    printf("---MENU RESTAURANTE---\n");
                    printf("1.Login.\n");
                    printf("2.Cadastro.\n");
                    printf("0.Sair.\n");

                    printf("Digite sua opcao:\n");
                    scanf("%d",&menu_restaurante_inicio);

                    system("cls");
                    switch(menu_restaurante_inicio)
                    {
                        case 0: break;

                        case 1: // feito
                            do{
                                printf("E-mail: ");
                                fflush(stdin);
                                fgets(auxR.email,50,stdin);
                                auxR.email[strcspn(auxR.email,"\n")]='\0';
                                retorno = confereEmail(auxR.email);
                                if(retorno){
                                    printf("E-mail inv�lido! Digite novamente.\n\n");
                                }
                                else if(procuraEmailRestaurante(lr,auxR.email)!=0){
                                    retorno = 1;
                                    printf("E-mail n�o cadastrado! Digite novamente.\n\n");
                                }
                            }while(retorno);
                            buscaItemRestaurante(lr,auxR.email,&auxR);
                            do{
                                printf("Senha: ");
                                escondeSenha(aux);
                                aux[strcspn(aux,"\n")]='\0';
                                retorno = confereSenha(aux);
                                if(retorno){
                                    printf("\nA senha deve conter pelo menos um caratere mai�sculo, um n�mero e um caractere especial! Digite novamente.\n\n");
                                }
                                else if(strcmp(aux, auxR.senha)!=0){
                                    printf("\nSenha incorreta! Digite novamente!\n");
                                    retorno = 1;
                                }
                            }while(retorno);

                            system("cls");
                            do
                            {
                                printf("Bem vindo, %s\n", auxR.nome_restaurante);
                                printf("1.Ver pratos.\n");// feito
                                printf("2.Ver pedidos.\n"); //feito
                                printf("3.Cadastrar prato.\n"); //feito
                                printf("4.Alterar prato.\n");//feito
                                printf("5.Excluir prato.\n");//feito
                                printf("6.Alterar dados do restaurante.\n");//feito
                                printf("7.Excluir conta.\n");//feito
                                printf("0.Sair.\n");//feito

                                printf("Digite sua opcao:\n");
                                scanf("%d",&menu_restaurante);

                                system("cls");
                                switch(menu_restaurante)
                                {
                                    case 0: break;

                                    case 1:
                                        printf("====== CARD�PIO ======\n");
                                        mostrarPratos(auxR.cardapio);
                                        printf("\n\nPressione qualquer tecla para voltar: ");
                                        fflush(stdin);
                                        fgetc(stdin);
                                        system("cls");
                                        break;

                                    case 2:
                                        do{
                                            printf("====== PEDIDOS ======\n");
                                            mostrarPedidos(auxR.pedidos);
                                            printf("\nDeseja entregar o primeiro pedido?\n");
                                            printf("1 - Sim\n");
                                            printf("0 - N�o\n");
                                            scanf("%d", &opcao);
                                            if(opcao){
                                                system("cls");
                                                retorno = removerPedido(auxR.pedidos, &auxC, &auxP);
                                                removerPrato(auxC.carrinho, auxP);
                                                if(retorno){
                                                    printf("\nERRO: n�o foi poss�vel entregar o pedido!\n");
                                                }
                                                else{
                                                    printf("\nPedido entregue!\n");
                                                }

                                            }
                                            printf("\n\nPressione qualquer tecla para sair: ");
                                            fflush(stdin);
                                            getc(stdin);
                                            system("cls");
                                        }while(opcao);
                                        break;

                                    case 3:
                                        printf("======= DADOS DE CADASTRO =======\n\n");
                                        printf("Nome: ");
                                        fflush(stdin);
                                        fgets(auxP.nome,29,stdin);
                                        auxP.nome[strcspn(auxP.nome,"\n")]='\0';

                                        printf("Pre�o: R$ ");
                                        scanf("%f", &auxP.preco);
                                        printf("Ingredientes (Ex. Arroz, Feij�o, Carne.): ");
                                        fflush(stdin);
                                        fgets(auxP.ingredientes,449,stdin);
                                        auxP.ingredientes[strcspn(auxP.ingredientes,"\n")]='\0';
                                        auxP.codigo = geraCodigo(lr);

                                        retorno = inserirPrato(auxR.cardapio, auxP);
                                        if(retorno){
                                            system("cls");
                                            printf("ERRO: n�o foi poss�vel inserir o prato!\n");
                                        }
                                        else{
                                            system("cls");
                                            printf("Prato inserido com sucesso!\n");
                                        }
                                        break;

                                    case 4:
                                        printf("======= ALTERA��O DE PRATO =======\n\n");

                                        printf("Digite o c�digo do prato: ");
                                        scanf("%d", &codigo);

                                        retorno = buscaItemPrato(auxR.cardapio, codigo, &auxP);
                                        if(retorno){
                                            printf("C�digo inv�lido!\n");
                                            break;
                                        }

                                        do{
                                            printf("Nome atual: %s\n", auxP.nome);
                                            printf("Deseja alterar o nome do prato?\n\n");
                                            printf("1. Sim\n");
                                            printf("0. N�o\n");
                                            printf("Op��o escolhida: ");
                                            scanf("%d",&opcao);

                                            system("cls");
                                            switch(opcao){
                                            case 1:
                                                printf("\nDigite o novo nome: ");
                                                fflush(stdin);
                                                fgets(auxP.nome,30,stdin);
                                                auxP.nome[strcspn(auxP.nome,"\n")]='\0';
                                                break;
                                            case 0:
                                                break;
                                            default:
                                                system("cls");
                                                printf("Op��o inv�lida, tente novamente!\n");
                                            }
                                        }while((opcao!=1)&&(opcao!=0));

                                        do{
                                            printf("Pre�o atual: %.2f\n", auxP.preco);
                                            printf("Deseja alterar o pre�o do prato?\n\n");
                                            printf("1. Sim\n");
                                            printf("0. N�o\n");
                                            printf("Op��o escolhida: ");
                                            scanf("%d",&opcao);

                                            system("cls");
                                            switch(opcao){
                                            case 1:
                                                printf("\nDigite o novo pre�o: ");
                                                scanf("%f", &auxP.preco);
                                                break;
                                            case 0:
                                                break;
                                            default:
                                                system("cls");
                                                printf("Op��o inv�lida, tente novamente!\n");
                                            }
                                        }while((opcao!=1)&&(opcao!=0));

                                        do{
                                            printf("Ingredientes atuais: %s\n", auxP.ingredientes);
                                            printf("Deseja alterar os ingredientes do prato?\n\n");
                                            printf("1. Sim\n");
                                            printf("0. N�o\n");
                                            printf("Op��o escolhida: ");
                                            scanf("%d",&opcao);

                                            system("cls");
                                            switch(opcao){
                                            case 1:
                                                printf("\nDigite os novos ingredientes: ");
                                                fflush(stdin);
                                                fgets(auxP.ingredientes,30,stdin);
                                                auxP.ingredientes[strcspn(auxP.ingredientes,"\n")]='\0';
                                                break;
                                            case 0:
                                                break;
                                            default:
                                                system("cls");
                                                printf("Op��o inv�lida, tente novamente!\n");
                                            }

                                        }while((opcao!=1)&&(opcao!=0));

                                        retorno = removerPrato(auxR.cardapio, auxP);
                                        if(retorno){
                                            system("cls");
                                            printf("ERRO: n�o foi poss�vel alterar o prato.\n");
                                        }
                                        else{
                                            retorno = inserirPrato(auxR.cardapio, auxP);
                                            if(retorno){
                                                system("cls");
                                                printf("ERRO: n�o foi poss�vel alterar o prato.\n");
                                            }
                                            else{
                                                system("cls");
                                                printf("Prato alterado com sucesso!\n");
                                            }
                                        }

                                        break;

                                    case 5:
                                        printf("Digite o c�digo do prato: ");
                                        scanf("%d", &codigo);

                                        retorno = buscaItemPrato(auxR.cardapio, codigo, &auxP);
                                        if(retorno){
                                            printf("ERRO: c�digo inv�lido!\n");
                                            break;
                                        }

                                        printf("Deseja mesmo excluir o prato permanentemente?\n");
                                        printf("1 - Sim\n");
                                        printf("0 - N�o\n");

                                        printf("Digite a sua op��o: ");
                                        scanf("%d", &opcao);

                                        while(opcao){
                                            retorno = removerPrato(auxR.cardapio, auxP);
                                            if(retorno){
                                                system("cls");
                                                printf("ERRO: n�o foi poss�vel remover o prato!\n");
                                            }
                                            else{
                                                opcao = 0;
                                                system("cls");
                                                printf("prato excluido com sucesso!\n");
                                            }
                                        }

                                        break;

                                    case 6://feito
                                        printf("======= ALTERA��O DE CADASTRO =======\n\n");

                                        do{
                                            printf("Nome atual: %s\n", auxR.nome_proprietario);
                                            printf("Deseja alterar seu nome de usu�rio?\n\n");
                                            printf("1. Sim\n");
                                            printf("0. N�o\n");
                                            printf("Op��o escolhida: ");
                                            scanf("%d",&opcao);

                                            system("cls");
                                            switch(opcao){
                                            case 1:
                                                printf("\nDigite seu novo nome de usu�rio: ");
                                                fflush(stdin);
                                                fgets(auxR.nome_proprietario,30,stdin);
                                                auxR.nome_proprietario[strcspn(auxR.nome_proprietario,"\n")]='\0';
                                                break;
                                            case 0:
                                                break;
                                            default:
                                                system("cls");
                                                printf("Op��o inv�lida, tente novamente!\n");
                                            }
                                        }while((opcao!=1)&&(opcao!=0));

                                        do{
                                            printf("Nome do estabelecimento atual: %s\n", auxR.nome_restaurante);
                                            printf("Deseja alterar o nome do estabelecimento?\n\n");
                                            printf("1. Sim\n");
                                            printf("0. N�o\n");
                                            printf("Op��o escolhida: ");
                                            scanf("%d",&opcao);

                                            system("cls");
                                            switch(opcao){
                                            case 1:
                                                printf("\nDigite seu novo nome de usu�rio: ");
                                                fflush(stdin);
                                                fgets(auxR.nome_restaurante,30,stdin);
                                                auxR.nome_restaurante[strcspn(auxR.nome_restaurante,"\n")]='\0';
                                                break;
                                            case 0:
                                                break;
                                            default:
                                                system("cls");
                                                printf("Op��o inv�lida, tente novamente!\n");
                                            }
                                        }while((opcao!=1)&&(opcao!=0));

                                        do{
                                            printf("E-mail atual: %s\n", auxR.email);
                                            printf("Deseja alterar seu e-mail?\n\n");
                                            printf("1. Sim\n");
                                            printf("0. N�o\n");
                                            printf("Op��o escolhida: ");
                                            scanf("%d",&opcao);

                                            system("cls");
                                            switch(opcao){
                                            case 1:
                                                printf("\nDigite seu novo e-mail: ");
                                                fflush(stdin);
                                                fgets(auxR.email,50,stdin);
                                                auxR.email[strcspn(auxR.email,"\n")]='\0';
                                                retorno = confereEmail(auxR.email);
                                                if(retorno){
                                                    system("cls");
                                                    printf("E-mail inv�lido, digite novamente!\n");
                                                    opcao = -1;
                                                }
                                                else if(procuraEmailRestaurante(lr,auxR.email)==0){
                                                    system("cls");
                                                    printf("E-mail j� cadastrado! Tente novamente.\n");
                                                }
                                                break;
                                            case 0:
                                                break;
                                            default:
                                                system("cls");
                                                printf("Op��o inv�lida, tente novamente!\n");
                                            }
                                        }while((opcao!=1)&&(opcao!=0));

                                        do{
                                            printf("Deseja alterar sua senha?\n\n");
                                            printf("1. Sim\n");
                                            printf("0. N�o\n");
                                            printf("Op��o escolhida: ");
                                            scanf("%d",&opcao);

                                            system("cls");
                                            switch(opcao){
                                            case 1:
                                                printf("Digite sua senha atual: ");
                                                escondeSenha(aux);
                                                aux[strcspn(aux,"\n")]='\0';
                                                if(strcmp(aux,auxR.senha)!=0){
                                                    system("cls");
                                                    printf("Senha incorreta!\n");
                                                    break;
                                                }
                                                printf("\nDigite sua nova senha (min. 8 caracteres): ");
                                                escondeSenha(auxR.senha);
                                                auxR.senha[strcspn(auxR.senha,"\n")]='\0';
                                                retorno = confereSenha(auxR.senha);
                                                if(retorno){
                                                    system("cls");
                                                    printf("A senha deve conter pelo menos um caratere mai�sculo, um n�mero e um caractere especial! Digite novamente.\n\n");
                                                    opcao = -1;
                                                }
                                                break;
                                            case 0:
                                                break;
                                            default:
                                                system("cls");
                                                printf("Op��o inv�lida, tente novamente!");
                                            }
                                        }while((opcao!=1)&&(opcao!=0));

                                        do{
                                            printf("Categoria atual: %s\n", auxR.categoria);
                                            printf("Deseja alterar sua categoria?\n\n");
                                            printf("1. Sim\n");
                                            printf("0. N�o\n");
                                            printf("Op��o escolhida: ");
                                            scanf("%d",&opcao);

                                            system("cls");
                                            switch(opcao){
                                            case 1:
                                                mostraCategoria(auxR.categoria);
                                                break;
                                            case 0:
                                                break;
                                            default:
                                                system("cls");
                                                printf("Op��o inv�lida, tente novamente!\n");
                                            }
                                        }while((opcao!=1)&&(opcao!=0));


                                        retorno = 1;
                                        if(removerRestaurante(lr,auxR)==0){
                                                retorno = inserirRestaurante(lr,auxR);
                                        }

                                        if(retorno){
                                            system("cls");
                                            printf("Erro ao alterar!\n");
                                        }
                                        else{
                                            system("cls");
                                            printf("Dados alterados com sucesso!\n");
                                        }

                                        break;

                                    case 7:
                                        printf("Deseja mesmo excluir a sua conta permanentemente?\n");
                                        printf("1 - Sim\n");
                                        printf("0 - N�o\n");

                                        printf("Digite a sua op��o: ");
                                        scanf("%d", &opcao);

                                        while(opcao){
                                            printf("Digite sua senha para confirmar: ");
                                            escondeSenha(aux);
                                            aux[strcspn(aux,"\n")]='\0';
                                            if(strcmp(aux,auxR.senha)==0){
                                                retorno = removerRestaurante(lr, auxR);
                                                if(retorno){
                                                    system("cls");
                                                    printf("ERRO: n�o foi poss�vel remover o restaurante!\n");
                                                }
                                                else{
                                                    opcao = 0;
                                                    menu_restaurante = 0;
                                                    system("cls");
                                                    printf("Conta excluida com sucesso!\n");
                                                }
                                            }
                                            else{
                                                system("cls");
                                                printf("Senha inv�lida! Tente novamente. \n");
                                            }
                                        }

                                        break;

                                    default:
                                        printf("Opcao invalida...Tente novamente.\n");
                                }
                            } while(menu_restaurante);

                            break;

                        case 2://feito

                            printf("======= DADOS DE CADASTRO =======\n\n");
                            printf("Nome: ");
                            fflush(stdin);
                            fgets(auxR.nome_proprietario,29,stdin);
                            auxR.nome_proprietario[strcspn(auxR.nome_proprietario,"\n")]='\0';
                            printf("Nome do Restaurante: ");
                            fflush(stdin);
                            fgets(auxR.nome_restaurante,29,stdin);
                            auxR.nome_restaurante[strcspn(auxR.nome_restaurante,"\n")]='\0';
                            do{
                                printf("CNPJ (XX.XXX.XXX/0001-XX): ");
                                fflush(stdin);
                                fgets(auxR.cnpj,18,stdin);
                                retorno = confereCNPJ(auxR.cnpj);
                                if(retorno){
                                    printf("CNPJ inv�lido! Digite novamente.\n\n");
                                }
                                else if(procuraItemRestaurante(lr,auxR.cnpj)==0){
                                    retorno = 1;
                                    printf("CNPJ j� cadastrado! Digite novamente.\n\n");
                                }
                            }while(retorno);

                            do{
                                printf("E-mail: ");
                                fflush(stdin);
                                fgets(auxR.email,50,stdin);
                                retorno = confereEmail(auxR.email);
                                auxR.email[strcspn(auxR.email,"\n")]='\0';
                                if(retorno){
                                    printf("E-mail inv�lido! Digite novamente.\n\n");
                                }
                                else if(procuraEmailRestaurante(lr,auxR.email)==0){
                                    retorno = 1;
                                    printf("E-mail j� cadastrado! Digite novamente.\n\n");
                                }
                            }while(retorno);

                            do{
                                printf("Senha (min. 8 caracteres): ");
                                fflush(stdin);
                                escondeSenha(auxR.senha);
                                retorno = confereSenha(auxR.senha);
                                if(retorno){
                                    printf("A senha deve conter pelo menos um caratere mai�sculo, um n�mero e um caractere especial! Digite novamente.\n\n");
                                }
                            }while(retorno);

                            mostraCategoria(categoria);
                            strcpy(auxR.categoria,categoria);

                            retorno = inserirRestaurante(lr, auxR);

                            system("cls");
                            if(retorno==0){
                                printf("Restaurante cadastrado com sucesso!\n\n");
                            }
                            else{
                                printf("Erro ao cadastrar!\n\n");
                            }
                            break;

                        default:
                            printf("Opcao invalida... Tente novamente.\n");
                    }
                } while(menu_restaurante_inicio);

                break;

                    default:
                        printf("Opcao invalida... Tente novamente.\n");
        }
    } while(menu_inicial);

    return 0;
}

int confereCPF(char *cpf){
    int i, tam=0;
    for(i=0; cpf[i]!='\0'; i++){
        if((i!=3 && i!=7 && i!=11) && (cpf[i]<'0' && cpf[i]>'9')) return -1;
        tam++;
    }
    if(cpf[11]!='-') return -1;
    if(cpf[3]!='.' || cpf[7]!='.') return -1;
    if(tam<14) return -1;
    return 0;
}

int confereEmail(char *email){
    int i, arroba=0, ponto = 0;
    for(i=0; email[i]!='\0'; i++){
        if(email[i]=='@') arroba++;
        else if(email[i]=='.' && arroba==1) ponto++;
    }
    if(arroba!=1) return -1;
    if(ponto!=1) return -1;

    return 0;
}

int confereSenha(char *senha){
    int i, maiuscula=0, numero = 0, especial = 0, tam=0;
    for(i=0; senha[i]!='\0'; i++){
        if(senha[i]>='A' && senha[i]<='Z') maiuscula++;
        else if(senha[i]>='1' && senha[i]<='9') numero++;
        else if((senha[i]>='!' && senha[i]<='@')||(senha[i]>=':' && senha[i]<='?')) especial++;
        tam++;
    }
    if(maiuscula && especial && numero &&(tam>=8)) return 0;
    return -1;
}

int confereCNPJ(char *cnpj){
    int i, tam=0;
    for(i=0; cnpj[i]!='\0'; i++){
        if((i!=2 && i!=6 && i<10 && i>15) && (cnpj[i]<'0' && cnpj[i]>'9')) return -1;
        tam++;
    }

    if(tam!=17) return -1;
    if(cnpj[15]!='-') return -1;
    if(cnpj[2]!='.' || cnpj[6]!='.') return -1;
    if(cnpj[10]!='/') return -1;
    if(cnpj[11]!='0' || cnpj[12]!='0' || cnpj[13]!='0' || (cnpj[14]!='1' && cnpj[14]!='2')) return -1;


    return 0;
}

void mostraCategoria(char *categoria){
    int op;

    do{
        printf("\nEscolha a categoria: \n");
        printf("1 - Bebidas\n");
        printf("2 - Cafeteria\n");
        printf("3 - Saud�vel e fitness\n");
        printf("4 - Fast food\n");
        printf("5 - Doces e bolos\n");
        printf("6 - Padaria\n");
        printf("7 - Comida japonesa\n");
        printf("8 - Frutos do mar\n");
        printf("9 - Massas\n");
        printf("10 - Pizzaria\n");
        printf("11 - Pastelaria\n");
        printf("12 - Hamburgueria\n");
        printf("13 - Churrascaria\n");
        printf("14 - Salgados\n");
        printf("15 - Sorveteria\n");
        printf("16 - Vegetariano e vegano\n");
        printf("17 - Sem categoria\n\n");

        printf("op��o: ");
        scanf("%d", &op);

        switch(op){
        case 1:
            strcpy(categoria,"Bebidas");
            break;
        case 2:
            strcpy(categoria,"Cafeteria");
            break;
        case 3:
            strcpy(categoria,"Saud�vel e fitness");
            break;
        case 4:
            strcpy(categoria,"Fast food");
            break;
        case 5:
            strcpy(categoria,"Doces e bolos");
            break;
        case 6:
            strcpy(categoria,"Padaria");
            break;
        case 7:
            strcpy(categoria,"Comida japonesa");
            break;
        case 8:
            strcpy(categoria,"Frutos do mar");
            break;
        case 9:
            strcpy(categoria,"Massas");
            break;
        case 10:
            strcpy(categoria,"Pizzaria");
            break;
        case 11:
            strcpy(categoria,"Pastelaria");
            break;
        case 12:
            strcpy(categoria,"Hamburgueria");
            break;
        case 13:
            strcpy(categoria,"Churrascaria");
            break;
        case 14:
            strcpy(categoria,"Salgados");
            break;
        case 15:
            strcpy(categoria,"Sorveteria");
            break;
        case 16:
            strcpy(categoria,"Vegetariano e vegano");
            break;
        case 17:
            strcpy(categoria,"Sem categoria");
            break;
        default:
            system("cls");
            printf("Op��o inv�lida! Digite novamente.\n\n");
        }
    }while(op<1 && op>16);

}

void escondeSenha (char *senha)
{
    int i = 0;
    char ch, senha_ast[15];

    while (i < 14)
    {
        ch = getch();
        if (ch == ' ') {
            --i;
        } else if (ch == '\b') {
            printf("\b \b");
            i -= 2;
        } else if (ch == '\r')
            break;
        else {
            senha_ast[i] = ch;
            printf("*");
        }
        ++i;
    }

    senha_ast[i] = '\0';
    strcpy(senha, senha_ast);
}
