#ifndef RESTAURANTE_H_INCLUDED
#define RESTAURANTE_H_INCLUDED
#include "prato.h"
#include "cliente.h"
#include "pedidos.h"

typedef struct lista_r ListaR;

typedef struct restaurante{

    char nome_restaurante[30];
    char nome_proprietario[30];
    char cnpj[19];
    char email[30];
    char senha[15];

    ListaP *cardapio;
    FilaPedidos *pedidos;


}Restaurante;

ListaR *criarR();

int inserirRestaurante(ListaR *lr, Restaurante it);
int removerRestaurante(ListaR *lr, Restaurante it);
int listaVaziaR(ListaR *lr);

int alterarRestaurante(ListaR *lr, Restaurante it);
int buscaItemRestaurante(ListaR *lr, char *cod, Restaurante *it);
int procuraItemRestaurante(ListaR *lr, char *cod);

#endif // RESTAURANTE_H_INCLUDED
