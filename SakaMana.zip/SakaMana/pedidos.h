#ifndef PEDIDOS_H_INCLUDED
#define PEDIDOS_H_INCLUDED

#include "prato.h"
#include "cliente.h"

typedef struct filaPedidos FilaPedidos;

FilaPedidos* criarF();

int inserirPedido (FilaPedidos *f, Cliente c, Prato p);

int removerPedido (FilaPedidos *f, Cliente *c, Prato *p);

#endif // PEDIDOS_H_INCLUDED
