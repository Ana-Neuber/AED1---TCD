#include "prototipos.h"
#include <stdio.h>
#include <stdlib.h>

typedef struct no_r{

    Restaurante dados;
    struct no_r* prox;
    struct no_r* ant;

}noR;

typedef struct no_c{

    Cliente dados;
    struct no_c* prox;
    struct no_c* ant;

}noC;

typedef struct no_p{

    Pratos dados;
    struct no_p* prox;
    struct no_p* ant;

}noP;

typedef struct lista_r{

    noR* inicio;

}ListaR;

typedef struct lista_c{

    noC* inicio;

}ListaC;

typedef struct lista_p{

    noP* inicio;

}ListaP;

ListaR *criar(){

    ListaR lr = (ListaR *)malloc(sizeof(ListaR));

    lr->inicio=NULL;

    return lr;

}

ListaC *criar(){

    ListaC lc = (ListaC *)malloc(sizeof(ListaC));

    lc->inicio=NULL;

    return lc;

}

ListaP *criar(){

    ListaP lp = (ListaP *)malloc(sizeof(ListaP));

    lp->inicio=NULL;

    return lp;


}


















