#include "prototipos.h"
#include <stdio.h>
#include <stdlib.h>

//fun��o que salva lista no arquivo
//fun��o que carrega lista com o arquivo

int main ( )
{
    int menu_inicial, menu_cliente_inicio, menu_cliente, menu_restaurante_inicio, menu_restaurante;

    FILE *f_cliente = NULL, *f_restaurante = NULL;

    f_cliente = fopen ("skmn-clientes", "w");
    if (f_cliente == NULL)
    {
        printf ("\nErro: nao foi possivel acessar o arquivo de clientes");
        return -1;
    }

    f_restaurante = fopen ("skmn-restaurantes", "w");
    if (f_restaurante == NULL)
    {
        printf ("\nErro: nao foi possivel acessar o arquivo de restaurante");
        return -1;
    }

    do
    {
        printf("---MENU---");
        printf("1.Cliente.\n");
        printf("2.Restaurante.\n");
        printf("0.Sair.\n");

        printf("Digite sua opcao:");
        scanf("%d",&menu_inicial);

        switch(menu_inicial)
        {
            case 0:
                printf("Saindo...\n");
                break;

            case 1:
                do
                {
                    printf("---MENU CLIENTE---\n");
                    printf("1.Login.\n");
                    printf("2.Cadastro.\n");
                    printf("0.Sair.\n");

                    printf("Digite sua opcao:\n");
                    scanf("%d",&menu_cliente_inicio);

                    switch(menu_cliente_inicio)
                    {
                        case 0: break;

                        case 1:
                            //Colocar scanf's e verifica��es de email e senha, junto com struct do cliente.

                            do
                            {
                                printf("Email:");
                                printf("Senha:");
                            }
                            while(); //Retorno da fun��o de confer�ncia.

                            do
                            {
                                printf("Bem vindo Cliente...\n");
                                printf("1.Ver restaurantes.\n");
                                printf("2.Ver pratos.\n");
                                printf("3.Ver carrinho.\n");
                                printf("4.Alterar cadastro.\n");
                                printf("5.Excluir conta.\n");
                                printf("0.Sair.\n");

                                printf("Digite sua opcao:\n");
                                scanf("%d",&menu_cliente);

                                switch(menu_cliente)
                                {
                                    case 0: break;

                                    case 1:
                                        //Fun��o ver restaurantes(mostrar).

                                        break;

                                    case 2:
                                        //Fun��o ver pratos(mostrar).

                                        break;

                                    case 3:
                                        //Fun��o para ver carrinho.

                                        break;

                                    case 4:
                                        //Fun��o de alterar o cadastro.

                                        break;

                                    case 5:
                                        //Fun��o de excluir a conta (dar um free nessa bomba).

                                        break;

                                    default:
                                        printf("Opcao invalida... Tente novamente.\n");
                                }
                            } while(menu_cliente);

                            break;

                        case 2:
                        //Escrever printf's e scanf's de todos os dados dos clientes.
                        //Conferir email e senha, verificar se est�o ambos dispon�veis, al�m de qualquer outra informa��o repetida.
                        //Se der bom, fazemos fun��o cadastro clientes direto, se n�o, fazer tudo de novo.

                        break;

                        default:
                            printf("Opcao invalida... Tente novamente.\n");
                    }
                } while(menu_cliente_inicio);

                break;

            case 2:
                do
                {
                    printf("---MENU RESTAURANTE---\n");
                    printf("1.Login.\n");
                    printf("2.Cadastro.\n");
                    printf("0.Sair.\n");

                    printf("Digite sua opcao:\n");
                    scanf("%d",&menu_restaurante_inicio);

                    switch(menu_restaurante_inicio)
                    {
                        case 0: break;

                        case 1:
                            //Colocar scanf's e verifica��es de email e senha, junto com struct do restaurante.

                            do
                            {
                                printf("Email:");
                                printf("Senha:");
                            } while(); //Retorno da fun��o de confer�ncia.

                            do
                            {
                                printf("Bem vindo proprietario...\n");
                                printf("1.Ver pratos.\n");
                                printf("2.Ver pedidos.\n"); //Opcional.
                                printf("3.Cadastrar prato.\n");
                                printf("4.Alterar prato.\n");
                                printf("5.Excluir prato.\n");
                                printf("6.Alterar dados do restaurante.\n");
                                printf("7.Excluir conta.\n");
                                printf("0.Sair.\n");

                                printf("Digite sua opcao:\n");
                                scanf("%d",&menu_restaurante);

                                switch(menu_restaurante)
                                {
                                    case 0: break;

                                    case 1:
                                        //Fun��o ver pratos(mostrar).

                                        break;

                                    case 2:
                                        //Fun��o ver pedidos(mostrar).

                                        break;

                                    case 3:
                                        //Fun��o para cadastrar prato.

                                        break;

                                    case 4:
                                        //Fun��o de alterar o prato.

                                        break;

                                    case 5:
                                        //Fun��o de excluir o prato (dar um free nessa bomba).

                                        break;

                                    case 6:
                                        //Alterar dados.

                                        break;

                                    case 7:
                                        //Excluir conta FREE NESSA BOMBA).

                                        break;

                                    default:
                                        printf("Opcao invalida...Tente novamente.\n");
                                }
                            } while(menu_restaurante);

                            break;

                        case 2:
                            //Escrever printf's e scanf's de todos os dados do restaurante.
                            //Conferir email e senha, verificar se est�o ambos dispon�veis, al�m de qualquer outra informa��o repetida.
                            //Se der bom, fazemos fun��o cadastro restaurante direto, se n�o, fazer tudo de novo.

                            break;

                        default:
                            printf("Opcao invalida... Tente novamente.\n");
                    }
                } while(menu_restaurante_inicio);

                break;

                    default:
                        printf("Opcao invalida... Tente novamente.\n");
        }
    } while(menu_inicial);

    fclose(f_cliente);
    fclose(f_restaurante);

    return 0;
}
