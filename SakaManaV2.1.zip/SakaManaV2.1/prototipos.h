#ifndef PROTOTIPOS_H_INCLUDED
#define PROTOTIPOS_H_INCLUDED

typedef struct pratos{

    char nome[30];
    char ingredientes[450];
    float preco;

}Pratos;


typedef struct cliente{

    char nome[30];
    char email[30];
    char cpf[12];
    char senha[15];

    ListaP *carrinho;

}Cliente;

typedef struct restaurante{

    char nome_restaurante[30];
    char nome_proprietario[30];
    char cnpj[15];
    char email[30];
    char senha[15];

    ListaP *cardapio;
    ListaP *pedidos;


}Restaurante;

typedef struct lista_r ListaR;
typedef struct lista_c ListaC;
typedef struct lista_p ListaP;

ListaR *criar();
ListaC *criar();
ListaP *criar();









#endif // PROTOTIPOS_H_INCLUDED
