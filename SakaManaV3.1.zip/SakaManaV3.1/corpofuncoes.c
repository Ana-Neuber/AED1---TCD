#include "prototipos.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct no_r{
    Restaurante dados;
    struct no_r* prox;
    struct no_r* ant;
}noR;

typedef struct no_c{
    Cliente dados;
    struct no_c* prox;
    struct no_c* ant;
}noC;

typedef struct no_p{
    Prato dados;
    struct no_p* prox;
    struct no_p* ant;
}noP;

typedef struct lista_r{
    noR* inicio;
}ListaR;

typedef struct lista_c{
    noC* inicio;
}ListaC;

typedef struct lista_p{
    noP* inicio;
}ListaP;

ListaR *criarR(){
    ListaR *lr = (ListaR *)malloc(sizeof(ListaR));
    lr->inicio=NULL;
    return lr;
}

ListaC *criarC(){
    ListaC *lc = (ListaC *)malloc(sizeof(ListaC));
    lc->inicio=NULL;
    return lc;
}

ListaP *criarP(){
    ListaP *lp = (ListaP *)malloc(sizeof(ListaP));
    lp->inicio=NULL;
    return lp;
}

int inserirRestaurante(ListaR *lr, Restaurante it){
    if(lr == NULL)return -2;
    noR *noLista = (noR*)malloc(sizeof(noR));
    noLista->dados = it;
    noLista->dados.cardapio = criarP();
    noLista->dados.pedidos = criarP();

    noLista->prox = lr->inicio;
    noLista->ant = NULL;
    if(listaVaziaR(lr) != 0)
        lr->inicio->ant = noLista;
    lr->inicio = noLista;
    return 0;
}

int inserirCliente(ListaC *lc, Cliente it){
    if(lc == NULL)return -2;
    noC *noLista = (noC*)malloc(sizeof(noC));
    noLista->dados = it;
    noLista->dados.carrinho = criarP();

    noLista->prox = lc->inicio;
    noLista->ant = NULL;
    if(listaVaziaC(lc) != 0)
        lc->inicio->ant = noLista;
    lc->inicio = noLista;
    return 0;
}

int inserirPrato(ListaP *lp, Prato it){
    if(lp == NULL)return -2;
    noP *noLista = (noP*)malloc(sizeof(noP));
    noLista->dados = it;

    noLista->prox = lp->inicio;
    noLista->ant = NULL;
    if(listaVaziaP(lp) != 0)
        lp->inicio->ant = noLista;
    lp->inicio = noLista;
    return 0;
}

int removerRestaurante(ListaR *lr, Restaurante it){
    if(lr == NULL) return -2;
    if(listaVaziaR(lr)==0)return -1;
    noR *no = lr->inicio;
    while(no != NULL){
        if(strcmp(no->dados.cnpj, it.cnpj)!=0){
            no = no->prox;
        }
        else break;
    }
    if(no==NULL) return -3;
    no->ant->prox = no->prox;
    no->prox->ant = no->ant;
    free(no);
    return 0;
}

int removerCliente(ListaC *lc, Cliente it){
    if(lc == NULL) return -2;
    if(listaVaziaC(lc)==0)return -1;
    noC *no = lc->inicio;
    while(no != NULL){
        if(strcmp(no->dados.cpf, it.cpf)!=0){
            no = no->prox;
        }
        else break;
    }
    if(no==NULL) return -3;
    no->ant->prox = no->prox;
    no->prox->ant = no->ant;
    free(no);
    return 0;
}

int removerPrato(ListaP *lp, Prato it){
    if(lp == NULL) return -2;
    if(listaVaziaP(lp)==0)return -1;
    noP *no = lp->inicio;
    while(no != NULL){
        if(strcmp(no->dados.codigo, it.codigo)!=0){
            no = no->prox;
        }
        else break;
    }
    if(no==NULL) return -3;
    no->ant->prox = no->prox;
    no->prox->ant = no->ant;
    free(no);
    return 0;
}

int listaVaziaR(ListaR *lr){
    if(lr == NULL) return -2;
    if(lr->inicio == NULL) return 0;
    else return -1;
}

int listaVaziaC(ListaC *lc){
    if(lc == NULL) return -2;
    if(lc->inicio == NULL) return 0;
    else return -1;
}

int listaVaziaP(ListaP *lp){
    if(lp == NULL) return -2;
    if(lp->inicio == NULL) return 0;
    else return -1;
}

int alterarRestaurante(ListaR *lr, Restaurante it){
    if(lr==NULL)return -2;
    if(listaVaziaR(lr)==0) return -1;
    noR *no = lr->inicio;
    while(no != NULL){
        if(strcmp(no->dados.cnpj, it.cnpj)!=0){
            no = no->prox;
        }
        else break;
    }
    if(no==NULL) return -3;
    if(it.nome_proprietario[0] != '0') strcpy(no->dados.nome_proprietario,it.nome_proprietario);
    if(it.nome_restaurante[0] != '0') strcpy(no->dados.nome_restaurante,it.nome_restaurante);
    if(it.email[0] != '0') strcpy(no->dados.email,it.email);
    //if(it.senha[0] != '0') strcpy(no->dados.senha,it.senha);

    return 0;
}

int alterarCliente(ListaC *lc, Cliente it){
    if(lc==NULL)return -2;
    if(listaVaziaC(lc)==0) return -1;
    noC *no = lc->inicio;
    while(no != NULL){
        if(strcmp(no->dados.cpf, it.cpf)!=0){
            no = no->prox;
        }
        else break;
    }
    if(no==NULL) return -3;
    if(it.nome[0] != '0') strcpy(no->dados.nome,it.nome);
    if(it.email[0] != '0') strcpy(no->dados.email,it.email);
    //if(it.senha[0] != '0') strcpy(no->dados.senha,it.senha);

    return 0;
}

int alterarPrato(ListaP *lp, Prato it){
    if(lp==NULL)return -2;
    if(listaVaziaP(lp)==0) return -1;
    noP *no = lp->inicio;
    while(no != NULL){
        if(strcmp(no->dados.codigo, it.codigo)!=0){
            no = no->prox;
        }
        else break;
    }
    if(no==NULL) return -3;
    if(it.nome[0] != '0') strcpy(no->dados.nome,it.nome);
    if(it.ingredientes[0] != '0') strcpy(no->dados.ingredientes,it.ingredientes);
    if(it.preco != 0) no->dados.preco = it.preco;
    return 0;
}

int buscaItemRestaurante(ListaR *lr, char *cod, Restaurante *it){
    if(lr==NULL)return -2;
    if(listaVaziaR(lr)==0) return -1;
    noR *no = lr->inicio;
    while(no != NULL){
        if(strcmp(no->dados.cnpj, cod)!=0){
            no = no->prox;
        }
        else break;
    }
    if(no==NULL) return -3;
    *it = no->dados;
    return 0;
}

int buscaItemCliente(ListaC *lc,char *cod, Cliente *it){
    if(lc==NULL)return -2;
    if(listaVaziaC(lc)==0) return -1;
    noC *no = lc->inicio;
    while(no != NULL){
        if(strcmp(no->dados.cpf, cod)!=0){
            no = no->prox;
        }
        else break;
    }
    if(no==NULL) return -3;
    *it = no->dados;
    return 0;
}

int buscaItemPrato(ListaP *lp,char *cod, Prato *it){
    if(lp==NULL)return -2;
    if(listaVaziaP(lp)==0) return -1;
    noP *no = lp->inicio;
    while(no != NULL){
        if(strcmp(no->dados.codigo, cod)!=0){
            no = no->prox;
        }
        else break;
    }
    if(no==NULL) return -3;
    *it = no->dados;
    return 0;
}

int procuraItemRestaurante(ListaR *lr, char *cod){
    if(lr==NULL)return -2;
    if(listaVaziaR(lr)==0) return -1;
    noR *no = lr->inicio;
    while(no != NULL){
        if(strcmp(no->dados.cnpj, cod)!=0){
            no = no->prox;
        }
        else return 0;
    }
    return -3;
}

int procuraItemCliente(ListaC *lc,char *cod){
    if(lc==NULL)return -2;
    if(listaVaziaC(lc)==0) return -1;
    noC *no = lc->inicio;
    while(no != NULL){
        if(strcmp(no->dados.cpf, cod)!=0){
            no = no->prox;
        }
        else return 0;
    }
    return -3;
}

int procuraItemPrato(ListaP *lp,char *cod){
    if(lp==NULL)return -2;
    if(listaVaziaP(lp)==0) return -1;
    noP *no = lp->inicio;
    while(no != NULL){
        if(strcmp(no->dados.codigo, cod)!=0){
            no = no->prox;
        }
        else return 0;
    }
    return -3;
}


















