#ifndef PROTOTIPOS_H_INCLUDED
#define PROTOTIPOS_H_INCLUDED

typedef struct lista_r ListaR;
typedef struct lista_c ListaC;
typedef struct lista_p ListaP;

typedef struct prato{

    char codigo[10];
    char nome[30];
    char ingredientes[450];
    float preco;

}Prato;


typedef struct cliente{

    char nome[30];
    char email[30];
    char cpf[12];
    char senha[15];

    ListaP *carrinho;

}Cliente;

typedef struct restaurante{

    char nome_restaurante[30];
    char nome_proprietario[30];
    char cnpj[15];
    char email[30];
    char senha[15];

    ListaP *cardapio;
    ListaP *pedidos;


}Restaurante;

ListaR *criarR();
ListaC *criarC();
ListaP *criarP();

int inserirRestaurante(ListaR *lr, Restaurante it);
int inserirCliente(ListaC *lc, Cliente it);
int inserirPrato(ListaP *lp, Prato it);

int removerRestaurante(ListaR *lr, Restaurante it);
int removerCliente(ListaC *lc, Cliente it);
int removerPrato(ListaP *lp, Prato it);

int listaVaziaR(ListaR *lr);
int listaVaziaC(ListaC *lc);
int listaVaziaP(ListaP *lp);

int alterarRestaurante(ListaR *lr, Restaurante it);
int alterarCliente(ListaC *lc, Cliente it);
int alterarPrato(ListaP *lp, Prato it);

int buscaItemRestaurante(ListaR *lr, char *cod, Restaurante *it);
int buscaItemCliente(ListaC *lc,char *cod, Cliente *it);
int buscaItemPrato(ListaP *lp,char *cod, Prato *it);

int procuraItemRestaurante(ListaR *lr, char *cod);
int procuraItemCliente(ListaC *lc,char *cod);
int procuraItemPrato(ListaP *lp,char *cod);













#endif // PROTOTIPOS_H_INCLUDED
