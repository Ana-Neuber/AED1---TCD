#ifndef PRATO_H_INCLUDED
#define PRATO_H_INCLUDED

typedef struct lista_p ListaP;

typedef struct prato{

    char codigo[10];
    char nome[30];
    char ingredientes[450];
    float preco;

}Prato;

ListaP *criarP();

int inserirPrato(ListaP *lp, Prato it);
int removerPrato(ListaP *lp, Prato it);
int listaVaziaP(ListaP *lp);

int alterarPrato(ListaP *lp, Prato it);
int buscaItemPrato(ListaP *lp,char *cod, Prato *it);
int procuraItemPrato(ListaP *lp,char *cod);


#endif // PRATO_H_INCLUDED
