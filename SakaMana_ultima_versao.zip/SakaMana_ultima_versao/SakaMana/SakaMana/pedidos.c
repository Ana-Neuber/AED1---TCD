#include "restaurante.h"
#include "prato.h"
#include "cliente.h"
#include "pedidos.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct noPedidos{
    struct noPedido *prox;
    Cliente dados;
    Prato pedido;
}NoPedidos;

typedef struct filaPedidos{
    NoPedidos* inicio;
    NoPedidos* fim;
    int quant;
}FilaPedidos;

FilaPedidos *criarF(){
    FilaPedidos *f = (FilaPedidos *)malloc(sizeof(FilaPedidos));
    f->inicio = NULL;
    f->fim = NULL;
    f->quant = 0;
    return f;
}

int inserirPedido (FilaPedidos *f, Cliente c, Prato p){
    if(f==NULL) return -2;
    NoPedidos *no = (NoPedidos*)malloc(sizeof(NoPedidos));
    no->dados = c;
    no->pedido = p;
    no->prox = NULL;
    if(f->quant == 0){
        f->inicio = no;
        f->fim = no;
    }
    else{
        f->fim->prox = no;
        f->fim = no;
    }

    f->quant++;
    return 0;
}

int removerPedido (FilaPedidos *f, Cliente *c, Prato *p){
    if(f==NULL)return -2;
    if(f->quant==0) return -1;

    *c = f->inicio->dados;
    *p = f->inicio->pedido;

    FilaPedidos *fila = f;
    if(fila->inicio == fila->fim){
        fila->fim = NULL;
    }
    fila->inicio = fila->inicio->prox;
    fila->quant--;
    free(fila);
    return 0;
}
